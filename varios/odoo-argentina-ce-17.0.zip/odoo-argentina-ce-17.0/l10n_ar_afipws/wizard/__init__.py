##############################################################################
# For copyright and license notices, see __manifest__.py file in module root
# directory
##############################################################################
from . import res_partner_update_from_padron_wizard
from . import upload_certificate_wizard
