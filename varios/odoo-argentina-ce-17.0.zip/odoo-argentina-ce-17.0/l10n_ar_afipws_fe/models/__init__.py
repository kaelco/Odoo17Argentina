##############################################################################
# For copyright and license notices, see __manifest__.py file in module root
# directory
##############################################################################
from . import account_move
from . import account_move_ws
from . import afipws_connection
from . import account_journal
from . import account_journal_ws
from . import res_config_settings
from . import res_company
