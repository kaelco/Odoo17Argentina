[![Coverage Status](https://coveralls.io/repos/ingadhoc/odoo-argentina/badge.png?branch=15.0)](https://coveralls.io/r/ingadhoc/odoo-argentina?branch=15.0)
[![Code Climate](https://codeclimate.com/github/ingadhoc/odoo-argentina/badges/gpa.svg)](https://codeclimate.com/github/ingadhoc/odoo-argentina)

# ADHOC odoo-argentina-ce

Repositoriy for odoo addons of argentinian localization for functionalities that are in odoo enterprise.
For any argentinan functionality that is not in odoo CE (community edition) or odoo EE (odoo enterprise), please refer to https://github.com/ingadhoc/odoo-argentina

[//]: # (addons)
[//]: # (end addons)

Translation Status
------------------
[![Transifex Status](https://www.transifex.com/projects/p/ingadhoc-odoo-argentina-15-0/chart/image_png)](https://www.transifex.com/projects/p/ingadhoc-odoo-argentina-15-0)

----

<img alt="ADHOC" src="http://fotos.subefotos.com/83fed853c1e15a8023b86b2b22d6145bo.png" />
**Adhoc SA** - www.adhoc.com.ar
