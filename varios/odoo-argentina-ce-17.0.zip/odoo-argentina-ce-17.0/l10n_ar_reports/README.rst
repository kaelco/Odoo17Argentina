.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
    :alt: License

Argentinian Reports (CE)
========================
Creates Sale and Purchase VAT report menus in "Accounting/Reporting/Argentina Statements"

Configuration
=============

TODO

Usage
=====

TODO

Know issues / Roadmap
=====================

TODO

Credits
=======

Contributors
------------

* TODO

Maintainer
----------

.. image:: http://odoo-argentina.org/logo.png
   :alt: Odoo Argentina
   :target: http://odoo-argentina.org

This module is maintained by the Odoo Argentina.

Odoo Argentina, is a nonprofit organization whose
mission is to support the collaborative development of Odoo features and
promote its widespread use.

To contribute to this module, please visit http://odoo-argentina.org
