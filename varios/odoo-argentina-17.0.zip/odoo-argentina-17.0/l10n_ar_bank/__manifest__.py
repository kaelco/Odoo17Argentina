{
    "name": "Listado de Bancos Argentinos",
    'version': "17.0.0.4.0",
    'category': 'Localization/Argentina',
    'sequence': 14,
    'author': 'ADHOC SA',
    'license': 'AGPL-3',
    'summary': '',
    'depends': [
        'base',
        'l10n_ar',
    ],
    'data': [
        'data/res_bank.xml',
    ],
    'installable': True,
    'auto_install': True,
    'application': False,
}
