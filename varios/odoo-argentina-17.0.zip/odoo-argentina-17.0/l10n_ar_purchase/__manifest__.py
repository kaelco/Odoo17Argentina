{
    'name': 'Argentinean Purchase',
    'version': "17.0.1.3.0",
    'category': 'Localization/Argentina',
    'sequence': 14,
    'author': 'ADHOC SA',
    'website': 'www.adhoc.com.ar',
    'license': 'AGPL-3',
    'summary': '',
    'depends': [
        'purchase',
        'l10n_ar',
    ],
    'external_dependencies': {
    },
    'data': [
        'views/purchase_report_templates.xml',
    ],
    'demo': [
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
