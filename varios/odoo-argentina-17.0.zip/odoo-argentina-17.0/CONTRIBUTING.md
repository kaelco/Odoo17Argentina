# ADHOC Guidelines

Please follow the official guide from [Odoo Argentina](https://github.com/ingadhoc/odoo-argentina/wiki).

## Project Specific Guidelines

This project does not have specific coding guidelines.

