from . import account_move
from . import account_payment
from . import l10n_latam_document_type
from . import account_payment_receiptbook
from . import account_chart_template
