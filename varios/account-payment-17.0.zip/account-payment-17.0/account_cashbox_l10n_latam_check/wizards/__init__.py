from . import l10n_latam_payment_mass_transfer
