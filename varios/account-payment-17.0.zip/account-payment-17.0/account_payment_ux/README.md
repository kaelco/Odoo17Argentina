[![Code Climate](https://codeclimate.com/github/ingadhoc/account-payment/badges/gpa.svg)](https://codeclimate.com/github/ingadhoc/account-payment)

# ADHOC Account Payment UX

- Block new payments on the same related invoice, once it has a pending transaction in process.

- When the electronic transaction is pending the payment will remain in draft status. After done this electronic transaction the payment changes its state and reconcilie with the invoices.

- Ignore write post processed TX flag in draft and pendding transaction.

----

<img alt="ADHOC" src="http://fotos.subefotos.com/83fed853c1e15a8023b86b2b22d6145bo.png" />
**Adhoc SA** - www.adhoc.com.ar
